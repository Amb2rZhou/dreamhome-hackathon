# DreamHome Frontend Spec Package

本包用于手动上传到 GitHub，作为当前 DreamHome 黑客松前端规范与主界面 demo 交付。

## 内容

```text
DreamHome-frontend-spec/
├── README.md
├── docs/
│   ├── FRONTEND_ARCHITECTURE_GUIDE.md
│   └── dreamhome-d-system.css
├── prototype/
│   └── main-interface-v1/
│       ├── index.html
│       ├── dreamhome-d-system.css
│       └── assets/
│           └── mascot/
│               └── states/
│                   ├── mascot-initial.png
│                   ├── mascot-idle.png
│                   ├── mascot-thinking.png
│                   ├── mascot-happy.png
│                   ├── mascot-working.png
│                   └── mascot-sleeping.png
└── assets/
    └── mascot/
        └── states/
            ├── mascot-initial.png
            ├── mascot-idle.png
            ├── mascot-thinking.png
            ├── mascot-happy.png
            ├── mascot-working.png
            └── mascot-sleeping.png
```

## 推荐上传到 GitHub 的路径

把本包内容对应放到队长仓库：

```text
mobile/docs/frontend/FRONTEND_ARCHITECTURE_GUIDE.md
mobile/docs/frontend/dreamhome-d-system.css
mobile/prototypes/main-interface-v1/index.html
mobile/prototypes/main-interface-v1/dreamhome-d-system.css
mobile/prototypes/main-interface-v1/assets/mascot/states/*.png
mobile/assets/mascot/states/*.png
```

## 本地预览

打开：

```text
prototype/main-interface-v1/index.html
```

如果需要用本地服务预览，可以在本包根目录运行：

```bash
python3 -m http.server 5180
```

然后打开：

```text
http://127.0.0.1:5180/prototype/main-interface-v1/
```

## 交付说明

当前包含：

- D 组生活方式治愈版设计规范
- 颜色 Token 与字号规范
- iPhone mockup 状态栏规范
- 主界面 HTML demo
- 右上角包公球桌宠 initial 状态接入
- 点击包公球触发时间问候气泡
- 6 张透明底包公球状态图

当前点击包公球的问候规则：

```text
05:00-11:00 早安
11:00-14:00 午安
14:00-18:00 下午好
18:00-23:00 晚上好
23:00-05:00 夜深了
```

气泡文案：

```text
{问候语}，今天想设计些什么呢？
```
