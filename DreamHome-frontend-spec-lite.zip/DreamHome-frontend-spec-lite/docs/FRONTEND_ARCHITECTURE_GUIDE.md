# DreamHome Frontend Architecture Guide

This document records the current mobile frontend direction for the DreamHome hackathon demo. It is intended for teammates to reuse the visual system, mascot assets, and main-interface interaction rules consistently.

## 1. Source Context

Product planning repository:

```text
https://github.com/Amb2rZhou/dreamhome-hackathon
```

Current product loop:

```text
See inspiration
  -> Excerpt / capture
  -> Save as assets / 3D components
  -> Assemble into a home space
  -> Share the dream home
```

Current mobile main interface structure:

```text
Topbar
- DreamHome kicker
- App title: 梦想豪宅
- Interactive mascot: 包公球

Hero Card
- 从灵感收集到设计拼装，
- 陪你慢慢来。

Module Cards
1. 灵感迸发！
   - 一键收集奇思妙想
   - Sub entries: 手绘 / 拍照上传 / 发现
2. 资产
   - 3D 组件素材库
3. 空间
   - 自由拼装家居

Bottom Navigation
- Home
- Assets
- Space
```

## 2. Repo File Layout

Frontend handoff files are stored under:

```text
mobile/
├── assets/
│   └── mascot/
│       └── states/
│           ├── mascot-initial.png
│           ├── mascot-idle.png
│           ├── mascot-thinking.png
│           ├── mascot-happy.png
│           ├── mascot-working.png
│           └── mascot-sleeping.png
├── docs/
│   └── frontend/
│       ├── FRONTEND_ARCHITECTURE_GUIDE.md
│       └── dreamhome-d-system.css
└── prototypes/
    └── main-interface-v1/
        └── index.html
```

The local working copy used during design iteration is:

```text
/Users/shemeiya/ClaudeWorkspace/outputs/dreamhome-frontend/pages/main-interface-v1/
```

For future local asset drops, use:

```text
/Users/shemeiya/ClaudeWorkspace/outputs/dreamhome-frontend/pages/main-interface-v1/assets/
```

## 3. Visual Direction

Final selected direction: D group, lifestyle healing version.

Design keywords:

```text
sage green
mist green
soft white card
large radius
low-pressure density
home lifestyle
light skeuomorphic mascot
```

## 4. Design Tokens

The current reusable CSS token file is:

```text
mobile/docs/frontend/dreamhome-d-system.css
```

Core tokens:

```css
--dh-color-ink-950: #1d241f;
--dh-color-mist-100: #f5fbf6;
--dh-color-mist-200: #e6efe4;
--dh-color-sage-300: #c7d7be;
--dh-color-sage-600: #70886f;
--dh-color-clay-200: #e7c3bb;
--dh-color-orange-500: #ff7a3d;
```

Current app background:

```css
--dh-bg-app: linear-gradient(
  180deg,
  #dcebd8 0%,
  #f7fbf5 42%,
  #ffffff 58%,
  #e1f0dd 100%
);
```

## 5. Typography Scale

Current main-interface typography:

| Role | Token | Size | Weight | Usage |
|---|---|---:|---:|---|
| Caption | `--dh-text-2xs` | 10px | 760 | labels, bottom nav micro text |
| Micro | `--dh-text-xs` | 11px | 650 | compact helper copy |
| Body | `--dh-text-sm` | 12px | 650 | card body copy |
| Card Title | `--dh-text-lg` | 16px | 760 | module card title |
| Section Title | `--dh-text-xl` | 20px | 850 | section title, currently used sparingly |
| Hero Title | `--dh-text-2xl` | 18px | 850 | hero card copy |
| App Title | `--dh-text-3xl` | 23px | 850 | top app title |

## 6. iPhone Mockup Rules

During desktop development, keep the iPhone shell visible.

The mockup includes:

```text
black phone shell
dynamic island
status time
signal / 5G / battery
screen radius
home indicator
```

Current statusbar tuning:

```css
.dh-island {
  top: 9px;
  width: 96px;
  height: 26px;
}

.dh-statusbar {
  height: 50px;
  padding: 20px 22px 0;
  font-size: 14px;
  line-height: 17px;
}

.status-time {
  font-size: 15px;
  line-height: 18px;
  transform: translateY(5px);
}

.status-icons {
  transform: translateY(1px);
}
```

## 7. Mascot: 包公球

The mascot is a key product identity element. It should be treated as an interactive desktop-pet component, not a static decorative icon.

### 7.1 Asset Requirements

Each mascot image must be a real transparent PNG:

```text
PNG RGBA
hasAlpha: yes
transparent alpha channel
no fake checkerboard background
no white baked-in background
```

Current state assets have been checked and meet this requirement.

### 7.2 State Assets

Stored in:

```text
mobile/assets/mascot/states/
```

Files:

```text
mascot-initial.png
mascot-idle.png
mascot-thinking.png
mascot-happy.png
mascot-working.png
mascot-sleeping.png
```

State mapping:

| State | File | Meaning | Suggested trigger |
|---|---|---|---|
| `initial` | `mascot-initial.png` | Initial / welcome form | default topbar mascot |
| `idle` | `mascot-idle.png` | Waiting | short inactivity |
| `thinking` | `mascot-thinking.png` | Thinking / interpreting inspiration | inspiration capture action |
| `happy` | `mascot-happy.png` | Positive feedback | successful save / interaction |
| `working` | `mascot-working.png` | Processing / generating | assembly or generation action |
| `sleeping` | `mascot-sleeping.png` | Resting | long inactivity |

### 7.3 Current First-Step Interaction

For the current main-interface prototype, only `mascot-initial.png` is enabled by default.

The mascot is placed at the top-right corner.

Click behavior:

```text
Tap mascot
  -> trigger slight pseudo-3D pop animation
  -> show greeting bubble
```

Greeting copy is based on system time:

| Time Range | Greeting |
|---|---|
| 05:00-11:00 | 早安 |
| 11:00-14:00 | 午安 |
| 14:00-18:00 | 下午好 |
| 18:00-23:00 | 晚上好 |
| 23:00-05:00 | 夜深了 |

Bubble format:

```text
{greeting}，今天想设计些什么呢？
```

Examples:

```text
早安，今天想设计些什么呢？
午安，今天想设计些什么呢？
下午好，今天想设计些什么呢？
晚上好，今天想设计些什么呢？
夜深了，今天想设计些什么呢？
```

### 7.4 Pseudo-3D Treatment

The mascot images are 2D PNGs. To make them feel more spatial in the UI, apply pseudo-3D treatment:

```css
.dh-mascot-button img {
  width: 58px;
  height: 58px;
  object-fit: contain;
  transform: translate(0, -7px) perspective(420px) rotateX(2deg);
  filter: drop-shadow(0 10px 14px rgba(63, 86, 64, .22));
}
```

On tap:

```css
.dh-mascot-button.is-tapped img {
  animation: mascot-pop .58s cubic-bezier(.2, 1.35, .28, 1) both;
}
```

### 7.5 Component Markup

```html
<button class="dh-icon-button dh-mascot-button" id="mascotButton" data-state="initial" aria-label="DreamHome 包公球">
  <img id="mascotImage" src="./assets/mascot/states/mascot-initial.png" alt="" />
  <span class="mascot-bubble" id="mascotBubble">今天想设计些什么呢？</span>
</button>
```

### 7.6 Time-Based Greeting Logic

```js
function getTimeGreeting(date = new Date()) {
  const hour = date.getHours();
  if (hour >= 5 && hour < 11) return '早安';
  if (hour >= 11 && hour < 14) return '午安';
  if (hour >= 14 && hour < 18) return '下午好';
  if (hour >= 18 && hour < 23) return '晚上好';
  return '夜深了';
}
```

## 8. Main Interface Prototype

Prototype path:

```text
mobile/prototypes/main-interface-v1/index.html
```

Current local preview path during design iteration:

```text
http://127.0.0.1:5178/pages/main-interface-v1/
```

Phone LAN preview example:

```text
http://<computer-lan-ip>:5178/pages/main-interface-v1/
```

## 9. Implementation Notes

1. Keep desktop previews inside the iPhone shell while tuning UI.
2. For eventual judge-facing iOS testing, create a separate full-screen route without the mock phone shell.
3. Do not use fake checkerboard PNGs for mascot assets; all mascot assets must have real alpha transparency.
4. Keep mascot state file names stable so the frontend can switch images without code changes.
5. The mascot should remain interactive and should not be flattened back into a static topbar icon.
